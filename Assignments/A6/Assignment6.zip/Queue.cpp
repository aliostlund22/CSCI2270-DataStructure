//Alison Ostlund
//A6
#include "Queue.h"
#include <sstream>
using namespace std;

Queue::~Queue(){
	//Will print goodbye after all code is done
	cout<<"Goodbye!"<<endl;
}

Queue::Queue(int value){
	//Initializes all relavant values;
	queueSize = value;
	queueCount = 0;
	arrayQueue = new string[value];
	queueHead = 0;
	queueTail = 0;
}

bool Queue::queueIsEmpty(){
	//Queue count is the amount of words in array, if = to 0 then array is empty
	if(queueCount == 0){
		return true;
	}
	return false;
}
bool Queue::queueIsFull(){
	//Queue size is the max amount of words allowed, if = to queue count then array is full
	if(queueCount == queueSize){
		return true;
	}
	return false;

}

void Queue::enqueue(string word){
	//cout<<"Hello"<<endl;
	if(!queueIsFull()){
		//cout<<"Test1"<<endl;
		//cout<<word<<endl;
		//cout<<queueTail<<endl;
		arrayQueue[queueTail] = word;
		queueCount++;
		if(queueTail == (queueSize-1)){
			queueTail = 0;
			//cout<<"Tail = 0;"<<endl;
		} else {
			queueTail++;
			//cout<<"Tail incremented"<<endl;
		}
		cout<<"E: "<<word<<endl;
		cout<<"H: "<<queueHead<<endl;
		cout<<"T: "<<queueTail<<endl;
	} else {
		cout<<"Queue is full."<<endl;
	}
}

string Queue::dequeue(){
	string word = arrayQueue[queueHead];
	if(!queueIsEmpty()){
		arrayQueue[queueHead] = "";
		queueCount--;
		if(queueHead == (queueSize - 1)){
			queueHead = 0;
		} else {
			queueHead++;
		}
		cout<<"H: "<<queueHead<<endl;
		cout<<"T: "<<queueTail<<endl;
		cout<<"word: "<<word<<endl;
	} else {
		cout<<"Queue is empty."<<endl;
	}
	return word;
}

void Queue::printQueue(){
	int temp = queueHead;
	if(queueCount == 0){
		cout<<"Empty"<<endl;
	} else {
		for (int i = 0; i < queueCount; i++){
			if(temp == queueSize){
				temp = 0; 
			}
			cout<<temp<<": "<<arrayQueue[temp]<<endl;
			temp++;
		}
	}
}
