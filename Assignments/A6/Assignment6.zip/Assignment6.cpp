//Alison Ostlund
//A6
#include "Queue.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

int main(){
	string userInput = "";
	Queue q(10);
	while(userInput != "5"){
		cout<<"======Main Menu====="<<endl;
		cout<<"1. Enqueue word"<<endl;
		cout<<"2. Dequeue word"<<endl;
		cout<<"3. Print queue"<<endl;
		cout<<"4. Enqueue sentence"<<endl;
		cout<<"5. Quit"<<endl; 
		cin>>userInput;
		cin.clear();
		if(userInput == "1"){
			cout<<"word: ";
			string enq; 
			//cin.ignore();
			cin>>enq;
			cin.clear(); 
			q.enqueue(enq);
		} else if (userInput == "2"){
			q.dequeue();
		} else if (userInput == "3"){
			q.printQueue();
		} else if (userInput == "4"){
			string sentence, word;
			cout<<"sentence: ";
			cin.ignore(); 
			getline(cin, sentence);
			stringstream ss(sentence);
			while(ss>>word){
				q.enqueue(word);
			}
		}
	}
}
