#include <iostream>

using namespace std;

struct Node{
	int key;
	Node *next;
	Node *previous;
	Node(int k, Node *n, Node *p){
		key = k;
		next = n;
		previous = p;
	}
};

class LinkedList{
	private:
		Node *head;
		Node *search(int value){

		}

	public:

		LinkedList(){head = NULL;};

		void getName()
		   {
			cout<<"Alison Ostlund";
		   }

		void addNode(int value, int newVal)
		{


            Node *temp = head;
            Node *newNode = new Node(newVal, NULL, NULL);



            if (value == NULL) //if at head
            {
                newNode->next = head->next;
                newNode->previous = head;

                head->next->previous = newNode;
                head->next = newNode;
            }
            else
            {
                while(temp != NULL)
                {
                    if(temp -> key == value){

                    newNode->next = temp->next;
                    newNode->previous = temp; // fix

                    temp->next->previous = newNode; // fix
                    temp->next = newNode;

                break; // fix
            }
            temp = temp->next;
        }

    }


}


   Node *getHead()
      {
		return head;

      }


		void printList(){
			Node *x = head;
			while(x != NULL){
				cout<<x->key<<endl;
				x = x->next;
			}
		}
};
